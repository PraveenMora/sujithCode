const Score = require("../models/score_model");


/**
 * Find all Urls
 */
exports.findAll = (req, res) => {

    Score.find()
        .sort({ url: -1 })
        .then((urls) => {
            res.status(200).send(urls);
        })
        .catch((err) => {
            res.status(500).send({
                message: err.message || "Error Occured",
            });
        });
};
/**
 * Find one User
 */
exports.findOne = (req, res) => {
    console.log(req.params.url);
    console.log(req.params.date);
        Score.find({ url: req.params.url, date: req.params.date}).then((url) => {
                console.log(url); // output all records
                res.status(200).send(url);
            })
        .catch((err) => {
            return res.status(500).send({
                message: "Error retrieving score " + req.params.siteurl,
            });
        });
};

// fetch based on MediaQueryList

exports.fetchBasedonQuery = (req, res) => {
    console.log("Hello");
    // Score.find({ url: req.params.siteurl, date: "20-02-2022"}).toArray(function (err, results) {
    //     console.log(results); // output all records
    //     res.status(200).send(results);
    // })

    // Score.find()
    // .sort({ url: -1 })
    // .then((urls) => {
    // res.status(200).send(urls);
    // }).catch((err) => {
    //     res.status(500).send({
    //         message: err.message || "Error Occured",
    //     });
    // });



};

// });

    // Score.find()
    // .sort({ url: -1 })
    // .then((urls) => {
    //   res.status(200).send(urls);
    // })

