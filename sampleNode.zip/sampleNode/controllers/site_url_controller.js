const Url = require("../models/user_model");
const API_KEY = 'AlzaSyC9nM8Br25HC5VTVQiRNokA2HJz-KKq_to';
const request = require('request');

/**
 * this method is to create the user
 */
exports.create = (req, res) => {

  /**
   * Create a site
   */
  const siteinfo = new Url({
    url: req.body.siteurl
  });

  /**
   * Save user to database
   */
  siteinfo
    .save()
    .then((data) => {
      res.send(data);
    })
    .catch((err) => {
      res.status(500).send({
        message: err.message || "Some error occurred while creating the User.",
      });
    });
};
/**
 * Find all Urls
 */
exports.findAll = (req, res) => {
    Url.find()
    .sort({ url: -1 })
    .then((urls) => {
      res.status(200).send(urls);
    })
    .catch((err) => {
      res.status(500).send({
        message: err.message || "Error Occured",
      });
    });
};
/**
 * Find one Url
 */
exports.findOne = (req, res) => {
    Url.find({ url: req.params.url})
    .then((url) => {
      if (!url) {
        return res.status(404).send({
          message: "url not found with siteurl " + req.params.siteurl,
        });
      }
      res.status(200).send(url);
      console.log(url);
    })
    .catch((err) => {
      return res.status(500).send({
        message: "Error retrieving user with siteurl " + req.params.siteurl,
      });
    });
};



/**
 * Update a url with the specified id in the request
 */
exports.UpdateUrl = (req, res) => {
  if (!req.body.siteurl ) {
    res.status(400).send({
      message: "required fields cannot be empty",
    });
  }

  var hero = {
    url: req.params.newsiteurl,
  }
  Url.update({url: req.params.oldsiteurl}, hero, function(err, hero) {
    if(err) {
        res.json({
            error : err
        })
    }
    res.json({
        message : "URL updated successfully"
    })
});
}

exports.runBatch = (req, res) => {
    // fetch urls from urlmetadata table as an array
    Url.find().then((urls) => {
      res.status(200).send(urls);
      urls.forEach(function (url) {
          // run api call for each url
          console.log(url + "url from database");
          request('https://www.googleapis.com/pagespeedonline/v5/runPagespeed?url=' + url + '&key=' + API_KEY, { json: true }, (err, response, body) => {
              if (err) {
                  response.json({
                      'status': 'error',
                      'message': err
                  })
              } else {
                  if (body.error) {
                      let errors = [];
                      for (var i = 0, len = body.error.errors.length; i < len; ++i) {
                          if (body.error.errors[i].reason == 'keyInvalid') {
                              errors.push('Your API KEY IS Invalid.');
                          }
                          if (body.error.errors[i].reason == 'mainResourceRequestFailed') {
                              errors.push('Your API KEY IS Invalid.')
                          } else {
                              errors.push(body.error.errors);
                          }
                      }
                      response.json({
                          'status': 'error',
                          'errors': errors
                      })
                  } else {
                      console.log("successful response" + response);
                      response.json({
                          'status': 'success',
                          'data': body
                      });
                      // insert score, url, date to score table
                  }
              }
          });


      });
  })
      .catch((err) => {
          res.status(500).send({
              message: err.message || "Error Occured",
          });
      });




  console.info('cron job completed');
}