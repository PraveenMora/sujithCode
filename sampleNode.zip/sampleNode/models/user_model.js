const mongoose = require("../db");
const schema = new mongoose.Schema(
  {
   url:{
       type: String
   }
  }
);

module.exports = mongoose.model("urlmetadata", schema);