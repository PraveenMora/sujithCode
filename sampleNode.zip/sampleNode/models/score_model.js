const mongoose = require("../db");
const schema = new mongoose.Schema(
    {
        date: {
            type: String
        },
        url: {
            type: String
        },
        score: {
            type: String
        }
    }
);

module.exports = mongoose.model("score", schema);