const express = require("express");
const router = express.Router({ mergeParams: true });

const userControllr = require("../controllers/site_url_controller");


// find one url scores list


router.put("/runbatch", userControllr.runBatch);


module.exports = router;