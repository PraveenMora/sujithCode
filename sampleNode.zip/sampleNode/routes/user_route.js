const express = require("express");
const router = express.Router();
const userControllr = require("../controllers/site_url_controller");


// find one url scores list
router.get("/:siteurl", userControllr.findOne);

// fetch all urls with latest score
router.get("/", userControllr.findAll);

// add url to url metadata table
router.post("/", userControllr.create);

//update url 
router.put("/:oldsiteurl/:newsiteurl", userControllr.UpdateUrl);



module.exports = router;