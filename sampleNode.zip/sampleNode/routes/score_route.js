const express = require("express");
const router = express.Router();
const scoreControllr = require("../controllers/score_controller");

// // find one url+date combination scores list
router.get("/:url/:date", scoreControllr.findOne);


// // fetch all scores of all urls
router.get("/", scoreControllr.findAll);

// fetch scores based on date and url
// router.get("/:siteurl", scoreControllr.fetchBasedonQuery);


module.exports = router;