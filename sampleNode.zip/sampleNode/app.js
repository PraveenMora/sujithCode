var express = require("express");
var app = express();
var bodyParser = require("body-parser");
var db = require("./db");
const Url = require("./models/user_model");

const API_KEY = 'AIzaSyC9nM8Br25HC5VTVQiRNokA2HJz-KKq_to';
const Score = require("./models/score_model");

const request = require('request');

const router = express.Router();

const cron = require("node-cron"); 

/**
 * parse requests of content-type - application/json
 */
app.use(bodyParser.json());
/**
 * parse requests of content-type - application/x-www-form-urlencoded
 */
app.use(bodyParser.urlencoded({ extended: false }));

app.use("/", router);

app.use("/urls", require("./routes/user_route"));

app.use("/runbatch", require("./routes/batch_route"));

app.use("/scores", require("./routes/score_route"));
app.listen(8008);
console.log("Listening to PORT 8008");

cron.schedule("* */10 * * * *",  function () {

    // fetch urls from urlmetadata table as an array
    Url.find().then((urls) => {
        console.log(urls);
        console.log("****** DATA FROM URL TABLE *****");
        urls.forEach(function (urlObject) {
            // run api call for each url
            console.log(urlObject.url + "url from database");
            // 'https://www.googleapis.com/pagespeedonline/v5/runPagespeed?url='+url+'&fields=lighthouseResult/categories/*/score&prettyPrint=false&strategy=mobile&category=performance&category=pwa&category=best-practices&category=accessibility&category=seo&key='
            // + API_KEY


            
            request('https://www.googleapis.com/pagespeedonline/v5/runPagespeed?url='+
            urlObject.url+'&fields=lighthouseResult/categories/*/score&prettyPrint=true&strategy=mobile&category=performance&key=AIzaSyC9nM8Br25HC5VTVQiRNokA2HJz-KKq_to',
             { json: true }, (err, response, body) => {

                console.log(body);
                if (err) {
                    console.log("Error"+ response);
                    response.json({
                        'status': 'error',
                        'message': err
                    })
                } else {
                    if (body.error) {
                        let errors = [];
                        for (var i = 0, len = body.error.errors.length; i < len; ++i) {
                            if (body.error.errors[i].reason == 'keyInvalid') {
                                errors.push('Your API KEY IS Invalid.');
                            }
                            if (body.error.errors[i].reason == 'mainResourceRequestFailed') {
                                errors.push('Your API KEY IS Invalid.')
                            } else {
                                errors.push(body.error.errors);
                            }
                        }
                        // response.json({
                        //     'status': 'error',
                        //     'errors': errors
                        // })
                    } else {
                        console.log("successful response" + (response.body));
                        console.log("successful response" +  (response.body.lighthouseResult).categories.performance.score);
                        
                        // response.json({
                        //     'status': 'success',
                        //     'data': body
                        // });
                        // insert score, url, date to score table
                        
                        const note = new Score({
                            url:urlObject.url,score:(response.body.lighthouseResult).categories.performance.score*100
                        });

                        note.save().then(result => {
                            console.log('score saved!')
                        }
                       
                    }
                }
            });


        });
    })
        .catch((err) => {
            res.status(500).send({
                message: err.message || "Error Occured",
            });
        });
    console.lgog('cron job completed');
});