'use strict';

const express = require('express');
const router = express.Router();
const API_KEY = 'AlzaSyC9nM8Br25HC5VTVQiRNokA2HJz-KKq_to';
const request = require('request');
const Url = require("../models/user_model");

var cron = require('cron');

module.exports.init = function () {
    console.log('hi');
    Url.find().then((urls) => {
        res.status(200).send(urls);
        urls.forEach(function (url) {
            
            console.log(url + "url from database");
            
        });
    })
        .catch((err) => {
            res.status(500).send({
                message: err.message || "Error Occured",
            });
        });
};

var cronJob = cron.job("0 */10 * * * *", function () {

    // fetch urls from urlmetadata table as an array
    Url.find().then((urls) => {
        res.status(200).send(urls);
        urls.forEach(function (url) {
            // run api call for each url
            console.log(url + "url from database");
            request('https://www.googleapis.com/pagespeedonline/v5/runPagespeed?url=' + url + '&key=' + API_KEY, { json: true }, (err, response, body) => {
                if (err) {
                    response.json({
                        'status': 'error',
                        'message': err
                    })
                } else {
                    if (body.error) {
                        let errors = [];
                        for (var i = 0, len = body.error.errors.length; i < len; ++i) {
                            if (body.error.errors[i].reason == 'keyInvalid') {
                                errors.push('Your API KEY IS Invalid.');
                            }
                            if (body.error.errors[i].reason == 'mainResourceRequestFailed') {
                                errors.push('Your API KEY IS Invalid.')
                            } else {
                                errors.push(body.error.errors);
                            }
                        }
                        response.json({
                            'status': 'error',
                            'errors': errors
                        })
                    } else {
                        console.log("successful response" + response);
                        response.json({
                            'status': 'success',
                            'data': body
                        });
                        // insert score, url, date to score table
                    }
                }
            });


        });
    })
        .catch((err) => {
            res.status(500).send({
                message: err.message || "Error Occured",
            });
        });




    console.info('cron job completed');
});
cronJob.start();

// router.get('/run batch', (req, res) => {
    // const url = req.body.url; 

