import React from "react";

export const Pagenotfound = () => (
  <div>
    <h2>Oops! Page Not Found..</h2>
    <p>
      Lorem ipsum dolor sit amet consectetur, adipisicing elit. Odit delectus
      porro natus explicabo maiores vero eos, dicta asperiores? Quam ducimus
      voluptate laudantium similique tenetur a doloribus quod, omnis nostrum
      dolorum.
    </p>
  </div>
);
