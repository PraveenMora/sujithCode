import React from "react";
import axios from "axios";
import { Chart } from "./Chart";
import {
  Container,
  Table,
  
  Dropdown,
  Row,
  Col,
  Button,
} from "react-bootstrap";
import { } from "react-bootstrap";
import Date from "./Date";
import "../components/Score.css";
import "./Search.css";


export class Score extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      tableData: [],
      error: null,
      isLoaded: false
    }
    
  }


  async getData() {
    // get all site scores on load
    let  resposedata = [{"score":10,"url":"facebook","date":"2020-02-21"},{"score":10,"url":"facebook","date":"2020-02-21"}];
    axios.get('http://localhost:8008/scores')
      .then(res => {
        console.log(res + "response from backend");
       
        console.log(res.data + "after api call");
        resposedata = res;
      })
      .catch(error => {
        if (error.response) {
          alert('Code: ' + error.response.data.error.code + '\r\nMessage: ' + error.response.data.error.message);
        } else {
          console.log('Error', error.message);
        }
      });

    return  resposedata;
  }
  renderBodywithValues(){
    console.log(this.state.tableData + "iside");
    const userList = [];
    for(let i = 0; i < this.state.tableData.length; i++) {
      
      let avatar = this.state.tableData[i].url;
      let email = this.state.tableData[i].score;
      let key = this.state.tableData[i].date;
      
      userList.push(<tr>
        <td>{avatar}</td>
        <td>{email}</td>
        <td>{key}</td>
      </tr> );
  }

  return userList;
  }
  componentDidMount() {
    // make ajax call to fetch all urls data
    // this.getData().then(result => this.setState({
    //   tableData: result
    // }))

    fetch("http://localhost:8008/scores").then(
      
      res => this.setState({isLoaded: true, tableData: res.data})
    )
  }



  render() {
    const { error, isLoaded, tableData } = this.state;
    return (
      <>
        <div>
          <Chart></Chart>
          <Row className='mt-4 mb-4'>
            <Col className='dropdown pr-0' style={{ display: "inline" }}>
              <Dropdown>
                <Dropdown.Toggle
                  variant='outline-dark btn-sm'
                  id='dropdown-basic'>
                  Select the URL for more details.
                  </Dropdown.Toggle>

                <Dropdown.Menu style={{ backgroundColor: "#73a47" }}>
                  <Dropdown.Item href='#'>Arabic</Dropdown.Item>
                  <Dropdown.Item href='#'>English</Dropdown.Item>
                </Dropdown.Menu>
              </Dropdown>
            </Col>
            <Col md='auto' xs='auto' className='pr-0'>
              <Date wrapperStyle='display: inline'>Select Date</Date>
            </Col>
            <Col md='auto' xs='auto'>
              <Button variant='success' className='search'>
                Search
                </Button>
            </Col>
          </Row>

          <Container className='p-0'>
          <ul>
          {tableData.map(item => (
            <li>
              {item.url} 
            </li>
          ))}
        </ul>
            <Table
              striped
              responsive
              bordered
              hover
              variant='dark'
              className='score'>
              <thead>
                <tr>
                  <th>URL</th>
                  <th>Performance</th>
                  <th>Fetch Time</th>
                </tr>
              </thead>
              <tbody>
              
              </tbody>


            </Table>
          </Container>
        </div>
      </>
    );
    // return (
    //   <div className='text-center loading'>
    //     <Container>
    //       <Spinner animation='border' />
    //       <p>Fetching Data Please wait...</p>
    //     </Container>
    //   </div>
    // );
  };
}

export default Score;
