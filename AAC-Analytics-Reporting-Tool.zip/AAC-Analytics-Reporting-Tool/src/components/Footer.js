import React, { Component } from "react";
import "./Footer.css";

export class Footer extends Component {
  render() {
    return (
      <div className='footer'>
        <h5>© 2021 ASSURANT, INC. ALL RIGHTS RESERVED</h5>
      </div>
    );
  }
}

export default Footer;
